from pydantic import BaseModel
from storage.database import update_cell_status, get_connection

class ClarifyRequest(BaseModel):
    user_id: str
    cell_id: str
    answer: str

def resolve_ambiguity(req: ClarifyRequest):
    """Updates the cell in SQLite with the user's clarification."""
    conn = get_connection()
    cursor = conn.cursor()
    
    # 1. Update the cell in blood_cells
    cursor.execute("""
        UPDATE blood_cells 
        SET status = 'active', 
            clarification_answer = ?,
            is_ambiguous = 0
        WHERE cell_id = ?
    """, (req.answer, req.cell_id))
    
    conn.commit()
    conn.close()
    
    return {"status": "resolved", "cell_id": req.cell_id}
