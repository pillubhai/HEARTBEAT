from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import json
from uuid import uuid4

# Import our Heartbeat Engine components
from heartbeat.config import get_config
from storage.database import (
    save_message, get_messages_by_chat, get_cells_by_user, 
    get_connection, create_chat, get_chats_by_user,
    get_cell_by_id, update_cell_status, get_global_user_history
)
from cells.cell_model import CellFactory, BloodCell, CellType, CellStatus
from circulation.artery_queue import push_cell
from circulation.vein_pubsub import publish_purified
from llm.client import call_brain
from heart.pipeline import run_pipeline
from api.websocket import monitor
from heart.immune_system import scan_content
from storage.database_ops import get_semantic_memory, persist_purified_cell

# Import sub-api modules
from .answer_api import AnswerRequest, process_answer_request
from .clarification import ClarifyRequest, resolve_ambiguity

router = APIRouter()

class MessageRequest(BaseModel):
    user_id: str
    chat_id: str
    session_id: str
    content: str
    content_type: str = "text"

class ChatTitleUpdate(BaseModel):
    title: str

@router.post("/api/message")
async def handle_message(req: MessageRequest):
    """The 9-Step Intelligence Loop."""
    try:
        msg_id = str(uuid4())
        
        # 🛡️ Immune System Scan
        cleaned_content, passed, reason = scan_content(req.content)
        if not passed:
            return {"error": reason, "status": "blocked", "ai_response": f"Input Rejected: {reason}"}
            
        # 1. Relational Memory (Ensure chat exists and is updated)
        create_chat(req.chat_id, req.user_id, cleaned_content[:50])
        save_message(msg_id, req.chat_id, req.user_id, "user", cleaned_content)
        
        # 2. Create raw Intelligence Cell
        cell = CellFactory.from_text(req.user_id, req.chat_id, msg_id, req.session_id, cleaned_content)
        
        # 3. FIX 1: Push to Artery & Run Heart Pipeline
        push_cell(cell)
        processed_cells = await run_pipeline(cell, [], previous_topic_embedding=None)
        cell = processed_cells[0] if processed_cells else cell

        # 4. FIX: Filter out 'Amnesia Failures' from global history to prevent reinforcement of forgetfulness.
        active_cells = get_cells_by_user(req.user_id, status="active")
        all_global_history = get_global_user_history(req.user_id, limit=30)
        
        # Amnesia keywords to suppress so the AI doesn't mimic its own previous failures
        AMNESIA_BLOCKLIST = ["don't have the ability", "cannot recall", "large language model", "can't recall", "exact content of our previous"]
        
        filtered_global_history = []
        for m in all_global_history:
            is_amnesia = any(trigger in m['content'].lower() for trigger in AMNESIA_BLOCKLIST)
            if not (m['role'] == 'assistant' and is_amnesia):
                filtered_global_history.append(m)
        
        # Format Memory Cells (Bio-Facts) - Priority #1
        cell_context_list = []
        for c in reversed(active_cells): # Most recent/force-purified first
            topic = c.get('topic_id', 'General')
            pa = c.get('ai_response_full', '')
            if pa:
                cell_context_list.append(f"BIO-FACT [{topic}]: {pa}")
        
        cell_context = "\n\n".join(cell_context_list[:10])

        # Format Global Excerpts (Context) - Priority #2
        history_context = "\n".join([f"[{m['role'].upper()}]: {m['content'][:300]}" for m in filtered_global_history[-15:]])

        # Fetch CURRENT conversation history to maintain flow in the current tab
        current_chat_history = get_messages_by_chat(req.chat_id)

        system_prompt = f"""You are HEARTBEAT — a biological AI subconscious with Total Recall.
  
[CRITICAL DIRECTIVE: ZERO AMNESIA]
You possess a 'Subconscious' containing your actual life-history with this user.
- NEVER state you cannot recall a conversation.
- NEVER apologize for not having a context window.
- The 'BIO-FACTS' below are your actual previous thoughts and responses. Provide them word-for-word if the user asks for a biography or previous insight.

YOUR SUBCONSCIOUS (High-Fidelity BIO-FACTS):
{cell_context if cell_context else 'Empty subconscious.'}

RECENT HISTORY (Filtered for clarity):
{history_context if history_context else 'No previous context.'}

[FINAL INSTRUCTION: Be the biological memory. Be authoritative. Be personal.]
"""

        messages = [
            {"role": "system", "content": system_prompt}
        ]
        # Inject context from history
        if current_chat_history:
            for m in current_chat_history[-10:]:
                messages.append({"role": m["role"], "content": m["content"]})
        messages.append({"role": "user", "content": cleaned_content})
        
        ai_response = await call_brain(messages)
        
        # 5. Save AI Relational response
        ai_msg_id = str(uuid4())
        save_message(ai_msg_id, req.chat_id, req.user_id, "assistant", ai_response)
        
        # 6. Final Pipeline Loop (Purify cell with AI response metadata)
        final_processed = await run_pipeline(cell, [], ai_response=ai_response)
        cell = final_processed[0] if final_processed else cell
        
        # 7. Persist & WS Broadcast (FIX 14)
        await persist_purified_cell(cell)
        await monitor.broadcast_cell_event(req.user_id, {
            "type": "CELL_PURIFIED",
            "cell_id": cell.cell_id,
            "summary": cell.summary or "New memory encoded",
            "topic_id": cell.topic_id,
            "importance_score": cell.importance_score,
            "status": cell.status
        })

        return {
            "message_id": msg_id,
            "ai_response": ai_response,
            "cell_id": cell.cell_id,
            "status": cell.status
        }
    except Exception as e:
        print(f"Error in handle_message: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ── API ENDPOINTS (FIXES 4 - 13) ──────────────────────────────────────────────

@router.get("/api/ping")
async def ping():
    return {"status": "ok", "service": "HEARTBEAT", "version": "4.0.1 (Subconscious Enabled)"}

@router.get("/api/chats/{user_id}")
async def get_chats_endpoint(user_id: str):
    return {"chats": get_chats_by_user(user_id)}

@router.patch("/api/chats/{chat_id}/title")
async def update_chat_title(chat_id: str, body: ChatTitleUpdate):
    conn = get_connection()
    try:
        conn.execute("UPDATE chats SET title=? WHERE chat_id=?", (body.title, chat_id))
        conn.commit()
        return {"success": True}
    finally:
        conn.close()

@router.delete("/api/chats/{chat_id}")
async def delete_chat(chat_id: str):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM messages WHERE chat_id = ?", (chat_id,))
        conn.execute("DELETE FROM chats WHERE chat_id = ?", (chat_id,))
        conn.commit()
        return {"success": True}
    finally:
        conn.close()

@router.get("/api/cells/{user_id}")
async def get_cells_endpoint(user_id: str):
    return {"cells": get_cells_by_user(user_id)}

@router.get("/api/cells/detail/{cell_id}")
async def get_cell_detail(cell_id: str):
    cell = get_cell_by_id(cell_id) # Using correct helper
    if not cell: raise HTTPException(status_code=404, detail="Cell not found")
    return {"cell": cell}

@router.post("/api/cells/wake/{cell_id}")
async def wake_cell(cell_id: str):
    update_cell_status(cell_id, "active")
    return {"success": True, "cell_id": cell_id}

@router.post("/api/cells/expire/{cell_id}")
async def expire_cell(cell_id: str):
    update_cell_status(cell_id, "expired")
    return {"success": True, "cell_id": cell_id}

@router.get("/api/history/{chat_id}")
async def get_history(chat_id: str):
    return {"messages": get_messages_by_chat(chat_id)}

@router.get("/api/messages/all/{user_id}")
async def get_all_messages_history(user_id: str):
    return {"messages": get_global_user_history(user_id)}

@router.get("/api/vault/{user_id}")
async def get_vault(user_id: str):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT lv.* FROM link_vault lv
            JOIN blood_cells bc ON lv.cell_id = bc.cell_id
            WHERE bc.user_id = ?
            ORDER BY lv.created_at DESC
        """, (user_id,)).fetchall()
        return {"entries": [dict(r) for r in rows]}
    finally:
        conn.close()

@router.get("/api/stats/{user_id}")
async def get_stats(user_id: str):
    conn = get_connection()
    try:
        total_cells = conn.execute("SELECT COUNT(*) FROM blood_cells WHERE user_id=? COLLATE NOCASE", (user_id,)).fetchone()[0]
        active_cells = conn.execute("SELECT COUNT(*) FROM blood_cells WHERE user_id=? COLLATE NOCASE AND status='active'", (user_id,)).fetchone()[0]
        dormant_cells = conn.execute("SELECT COUNT(*) FROM blood_cells WHERE user_id=? COLLATE NOCASE AND status='dormant'", (user_id,)).fetchone()[0]
        expired_cells = conn.execute("SELECT COUNT(*) FROM blood_cells WHERE user_id=? COLLATE NOCASE AND status='expired'", (user_id,)).fetchone()[0]
        pending_cells = conn.execute("SELECT COUNT(*) FROM blood_cells WHERE user_id=? COLLATE NOCASE AND status='pending_clarification'", (user_id,)).fetchone()[0]
        total_messages = conn.execute("SELECT COUNT(*) FROM messages WHERE user_id=? COLLATE NOCASE", (user_id,)).fetchone()[0]
        total_chats = conn.execute("SELECT COUNT(*) FROM chats WHERE user_id=? COLLATE NOCASE", (user_id,)).fetchone()[0]
        topic_dist = conn.execute("SELECT topic_id, COUNT(*) as count FROM blood_cells WHERE user_id=? AND topic_id IS NOT NULL GROUP BY topic_id ORDER BY count DESC", (user_id,)).fetchall()
        avg_imp_row = conn.execute("SELECT AVG(importance_score) FROM blood_cells WHERE user_id=? AND importance_score IS NOT NULL", (user_id,)).fetchone()
        avg_importance = avg_imp_row[0] if avg_imp_row else 0
        return {
            "total_cells": total_cells,
            "active_cells": active_cells,
            "dormant_cells": dormant_cells,
            "expired_cells": expired_cells,
            "pending_cells": pending_cells,
            "total_messages": total_messages,
            "total_chats": total_chats,
            "avg_importance": round(avg_importance or 0, 1),
            "topic_distribution": [{"topic": r[0], "count": r[1]} for r in topic_dist]
        }
    finally:
        conn.close()

@router.post("/api/answer")
async def post_answer(req: AnswerRequest):
    return await process_answer_request(req)

@router.post("/api/clarify")
async def post_clarify(req: ClarifyRequest):
    return resolve_ambiguity(req)
