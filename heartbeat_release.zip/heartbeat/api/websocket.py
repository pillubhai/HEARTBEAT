from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List

class HeartbeatMonitor:
    """Manages constant live feed connections."""
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        self.active_connections[user_id].append(websocket)

    def disconnect(self, websocket: WebSocket, user_id: str):
        if user_id in self.active_connections:
            self.active_connections[user_id].remove(websocket)

    async def broadcast_cell_event(self, user_id: str, message: dict):
        """Sends live cell status to all of the user's open monitors."""
        if user_id in self.active_connections:
            for connection in self.active_connections[user_id]:
                await connection.send_json(message)

monitor = HeartbeatMonitor()

async def websocket_endpoint(websocket: WebSocket, user_id: str):
    """Real-time WS Handler."""
    await monitor.connect(websocket, user_id)
    try:
        # Keep connection open
        while True:
            data = await websocket.receive_text()
            # Heartbeat (Ping) loop if needed
    except WebSocketDisconnect:
        monitor.disconnect(websocket, user_id)
