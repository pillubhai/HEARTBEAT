import redis
import json
from heartbeat.config import get_config
from cells.cell_model import BloodCell

# Redis connection singleton helper
_redis_conn = None

def get_redis_connection():
    """Returns a shared Redis connection instance."""
    global _redis_conn
    if _redis_conn is None:
        config = get_config()
        _redis_conn = redis.Redis(
            host=config.redis_host,
            port=config.redis_port,
            decode_responses=True
        )
    return _redis_conn

def push_cell(cell: BloodCell) -> bool:
    """Stores a cell in the heartbeat:artery Hash or local fallback."""
    try:
        r = get_redis_connection()
        r.ping() # Check connection
        r.hset("heartbeat:artery", cell.cell_id, cell.model_dump_json())
        return True
    except Exception:
        # Fallback: We don't have Redis, but we continue anyway for local dev
        print("[Memory-Logic] Redis offline, skipping artery push (Local Dev Mode)")
        return True

def pop_cell(cell_id: str) -> BloodCell:
    """Retrieves and deletes a cell from the artery."""
    r = get_redis_connection()
    try:
        data = r.hget("heartbeat:artery", cell_id)
        if data:
            r.hdel("heartbeat:artery", cell_id)
            # Pydantic v2 uses model_validate_json()
            return BloodCell.model_validate_json(data)
        return None
    except Exception as e:
        print(f"Error popping from artery: {e}")
        return None

def list_all_cells() -> list:
    """Utility to list all cells currently in the artery."""
    r = get_redis_connection()
    try:
        return [BloodCell.model_validate_json(v) for v in r.hvals("heartbeat:artery")]
    except Exception as e:
        print(f"Error listing artery: {e}")
        return []
