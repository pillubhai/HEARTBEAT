import redis
import json
from heartbeat.config import get_config
from cells.cell_model import BloodCell

def publish_purified(cell: BloodCell):
    """Publishes a purified cell or logs locally if Redis is off."""
    try:
        config = get_config()
        r = redis.Redis(host=config.redis_host, port=config.redis_port, decode_responses=True)
        r.ping()
        r.publish("vein:purified", cell.model_dump_json())
    except Exception:
        print(f"[Vein-Logic] Redis offline, memory purified locally: {cell.cell_id}")

async def subscribe_purified(callback):
    """Subscribes to vein:purified and runs the callback for each message."""
    config = get_config()
    r = redis.Redis(host=config.redis_host, port=config.redis_port, decode_responses=True)
    pubsub = r.pubsub()
    pubsub.subscribe("vein:purified")
    
    print("Listening on vein:purified...")
    for message in pubsub.listen():
        if message['type'] == 'message':
            data = message['data']
            # Pydantic v2 uses model_validate_json()
            cell = BloodCell.model_validate_json(data)
            await callback(cell)
