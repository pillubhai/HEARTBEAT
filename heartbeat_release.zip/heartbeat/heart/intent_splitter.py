import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from typing import List

def count_action_verbs(text: str) -> int:
    """Counts distinct action verbs in the text using NLTK."""
    words = word_tokenize(text)
    tagged = nltk.pos_tag(words)
    # Filter for verbs (VB, VBD, VBG, VBN, VBP, VBZ)
    verbs = {word.lower() for word, tag in tagged if tag.startswith('VB')}
    return len(verbs)

def split_by_conjunctions(text: str) -> List[str]:
    """Splits the text on common conjunctions."""
    conjunctions = ["and also", "and", "but also", "also", "additionally", "furthermore", "plus"]
    splits = [text]
    
    for conj in conjunctions:
        new_splits = []
        for s in splits:
            if conj in s:
                parts = s.split(conj)
                new_splits.extend([p.strip() for p in parts if p.strip()])
            else:
                new_splits.append(s)
        splits = new_splits
    return splits

def merge_short_splits(splits: List[str], min_words: int = 4) -> List[str]:
    """Merges splits that are too short back into the previous split."""
    if not splits:
        return []
    
    merged = []
    current = ""
    
    for s in splits:
        if not current:
            current = s
        elif len(s.split()) < min_words:
            current += " " + s
        else:
            merged.append(current)
            current = s
    
    if current:
        merged.append(current)
    
    return merged

def split_intents(text: str) -> List[str]:
    """Main function for multi-intent splitting using NLTK."""
    verb_count = count_action_verbs(text)
    
    if verb_count <= 1:
        return [text]
    
    raw_splits = split_by_conjunctions(text)
    final_splits = merge_short_splits(raw_splits)
    
    return final_splits if len(final_splits) > 1 else [text]
