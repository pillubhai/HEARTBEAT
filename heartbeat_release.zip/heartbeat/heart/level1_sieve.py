import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from typing import Optional

# Download required NLTK data (should be done once)
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('averaged_perceptron_tagger')

def load_nlp_model():
    """Ensures NLP models are ready."""
    return None

def remove_filler_words(text: str) -> str:
    """Removes common filler words from the text."""
    fillers = ["um", "uh", "so", "yeah", "basically", "honestly", "like", "you know"]
    words = word_tokenize(text)
    cleaned_words = [w for w in words if w.lower() not in fillers]
    # Simple join, though punct handling could be better
    return " ".join(cleaned_words).replace(" .", ".").replace(" ,", ",").replace(" ?", "?")

def is_pure_small_talk(text: str) -> bool:
    """Returns True if the text is only greetings or farewells."""
    small_talk = ["hello", "hi", "how are you", "good morning", "bye", "thanks", "thank you", "hey"]
    clean_text = text.lower().strip(",.?! ")
    return clean_text in small_talk

def extract_meaningful_content(text: str) -> Optional[str]:
    """Uses NLTK to extract sentences that contain nouns or verbs."""
    sentences = sent_tokenize(text)
    meaningful_sentences = []
    
    for sent in sentences:
        words = word_tokenize(sent)
        tagged = nltk.pos_tag(words)
        # NLTK tags: NN (Noun), VB (Verb)
        has_noun_or_verb = any(tag.startswith('NN') or tag.startswith('VB') for word, tag in tagged)
        if has_noun_or_verb:
            meaningful_sentences.append(sent.strip())
    
    return " ".join(meaningful_sentences) if meaningful_sentences else None

def sieve(raw_text: str) -> dict:
    """Main function for L1 processing using NLTK."""
    if not raw_text or not raw_text.strip():
        return {"cleaned": None, "removed": raw_text, "passed": False}
    
    if is_pure_small_talk(raw_text):
        return {"cleaned": None, "removed": raw_text, "passed": False}
    
    cleaned = remove_filler_words(raw_text)
    extracted = extract_meaningful_content(cleaned)
    
    if not extracted:
        return {"cleaned": None, "removed": raw_text, "passed": False}
    
    return {
        "cleaned": extracted,
        "removed": raw_text if extracted != raw_text else "",
        "passed": True
    }
