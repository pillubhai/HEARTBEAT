import asyncio
import logging
from datetime import datetime
from storage.database import get_connection
from api.websocket import monitor

async def automated_decay_job():
    """
    Background worker that purges expired cells periodically.
    Async version to allow WebSocket broadcasts.
    """
    print("🧬 METABOLISM: Automated Decay Job Started")
    userId = "MASTER_USER" # Default for now
    
    while True:
        try:
            conn = get_connection()
            cursor = conn.cursor()
            
            now = datetime.utcnow().isoformat()
            
            # 1. Identify expired cells
            cursor.execute("SELECT cell_id FROM blood_cells WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < ?", (now,))
            expired = cursor.fetchall()
            
            if expired:
                print(f"🧬 METABOLISM: Found {len(expired)} expired cells. Moving to Dormant.")
                for row in expired:
                    cell_id = row['cell_id']
                    cursor.execute("UPDATE blood_cells SET status = 'dormant' WHERE cell_id = ?", (cell_id,))
                    
                    # 📢 BROADCAST TO DASHBOARD
                    try:
                        await monitor.broadcast_cell_event(userId, {
                            "type": "CELL_EXPIRED",
                            "summary": "Life cycle complete. Cell moved to dormant storage.",
                            "cell_id": cell_id
                        })
                    except: pass
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logging.error(f"Decay Job Error: {e}")
            
        # Sleep for 1 hour (3600 seconds)
        await asyncio.sleep(3600)

def start_metabolism():
    """Starts the metabolism loop in the current event loop."""
    asyncio.create_task(automated_decay_job())
