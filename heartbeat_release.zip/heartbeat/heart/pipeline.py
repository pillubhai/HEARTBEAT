import logging
from datetime import datetime
from typing import List, Optional
from cells.cell_model import BloodCell, CellStatus, CellType
from heart import level1_sieve, level2_valve, level3_purifier
from storage.database import get_cells_by_user, update_cell_status, save_link_vault_entry
from api.websocket import monitor

async def run_pipeline(raw_cell: BloodCell, context_messages: List[str] = [], previous_topic_embedding: Optional[List[float]] = None, ai_response: Optional[str] = None) -> List[BloodCell]:
    """Main orchestrator function for the Heart pipeline."""
    try:
        # STEP 1-3: Filtering and Ambiguity (Only if no AI response yet)
        cleaned_text = raw_cell.user_raw_content
        if not ai_response:
            print(f"STEP 1: Sieve - {raw_cell.cell_id}")
            sieve_res = level1_sieve.sieve(raw_cell.user_raw_content)
            if not sieve_res["passed"]:
                print("Sieve failed - dismissing cell.")
                raw_cell.status = CellStatus.expired
                return [raw_cell]
            
            cleaned_text = sieve_res["cleaned"]
            
            print(f"STEP 2: Valve - {cleaned_text}")
            valve_res = await level2_valve.valve(cleaned_text, context_messages, previous_topic_embedding)
            
            if valve_res.intent_type in ["noise", "small_talk"]:
                print(f"Intent {valve_res.intent_type} - dismissing cell.")
                raw_cell.status = CellStatus.expired
                return [raw_cell]
            
            if valve_res.is_ambiguous:
                print(f"Ambiguity detected: {valve_res.ambiguous_word}")
                raw_cell.status = CellStatus.pending_clarification
                raw_cell.is_ambiguous = True
                raw_cell.clarification_question = valve_res.clarification_question
                return [raw_cell]
        
        # STEP 4: Intent Split (Only during initial processing)
        if not ai_response and len(valve_res.splits) > 1:
            print(f"Split detected: {len(valve_res.splits)} intents")
            child_cells = []
            for i, split in enumerate(valve_res.splits):
                # Create copies or new cells for each split
                child = raw_cell.copy(deep=True, update={
                    "user_raw_content": split,
                    "user_content": split,
                    "is_chain": True,
                    "part_number": i + 1,
                    "total_parts": len(valve_res.splits)
                })
                # Re-run pipeline for child (recursively or sequentially)
                # For simplicity in this phase, we return them to be re-processed or processed here
                # Here we process them sequentially for completion
                processed_children = await run_pipeline(child, context_messages, previous_topic_embedding)
                child_cells.extend(processed_children)
            return child_cells

        # STEP 5: Purify (This is the stage where memory is actually formed)
        print("STEP 3: Purify")
        purify_res = await level3_purifier.purify(cleaned_text, ai_response)
        
        # Update cell fields
        raw_cell.user_content = purify_res.user_content
        raw_cell.ai_response_summary = purify_res.ai_response_summary
        raw_cell.ai_response_full = purify_res.ai_response_full
        raw_cell.ai_response_type = purify_res.ai_response_type
        raw_cell.importance_score = purify_res.importance_score
        raw_cell.keywords = purify_res.keywords
        raw_cell.topic_id = purify_res.topic_id
        raw_cell.summary = purify_res.summary
        raw_cell.expires_at = purify_res.expires_at
        
        # 🔗 LINK CELL LOGIC (09)
        if purify_res.is_link:
            print(f"🔗 LINK DETECTED: {purify_res.link_id}")
            save_link_vault_entry(purify_res.link_id, raw_cell.cell_id, "text", ai_response, 1, 1)
            raw_cell.link_id = purify_res.link_id

        # 🧪 PRESSURE LOGIC (07): Fact Supremacy
        # Expire older cells that share same topic or core keywords
        print("PRESSURE LOGIC: Checking for collisions")
        try:
            active_cells = get_cells_by_user(raw_cell.user_id, status="active")
            for old_c in active_cells:
                # Simple collision check: same topic AND high keyword overlap
                if old_c["topic_id"] == raw_cell.topic_id:
                    print(f"Collision Detected! Expiring old cell {old_c['cell_id']} for topic {raw_cell.topic_id}")
                    update_cell_status(old_c["cell_id"], "expired")
                    # Broadcast to dashboard
                    await monitor.broadcast_cell_event(raw_cell.user_id, {
                        "type": "FACT_SUPREMACY",
                        "summary": f"Overwriting outdated memory for topic: {raw_cell.topic_id}",
                        "cell_id": old_c["cell_id"]
                    })
        except Exception as e:
            print(f"Pressure logic warning: {e}")
        
        # STEP 6: Finalize
        raw_cell.status = CellStatus.active
        raw_cell.cell_type = CellType.purified
        raw_cell.purified_at = datetime.utcnow()
        
        print(f"Pipeline complete: {raw_cell.cell_id} | Topic: {raw_cell.topic_id}")
        return [raw_cell]

    except Exception as e:
        return [handle_pipeline_error(raw_cell, e)]

def handle_pipeline_error(cell: BloodCell, error: Exception) -> BloodCell:
    """Logs error and marks cell as expired/error."""
    logging.error(f"Pipeline error for cell {cell.cell_id}: {error}")
    cell.status = CellStatus.expired
    return cell
