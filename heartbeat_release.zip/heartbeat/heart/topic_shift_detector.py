import os
import logging

# ── SILENCE ALL NOISY LOGS BEFORE IMPORTS ────────────────────────────────────
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
os.environ["SENTENCE_TRANSFORMERS_HOME"] = os.path.join(os.path.expanduser("~"), ".cache", "sentence_transformers")

# Suppress tqdm progress bars (the "Loading weights: 100%|██████|" bar)
os.environ["TQDM_DISABLE"] = "1"

# Suppress all transformer-related loggers
for _logger_name in [
    "transformers", "transformers.modeling_utils",
    "sentence_transformers", "huggingface_hub",
    "filelock", "torch"
]:
    logging.getLogger(_logger_name).setLevel(logging.ERROR)

from dotenv import load_dotenv
load_dotenv()
os.environ["HF_TOKEN"] = os.getenv("HF_TOKEN", "")

from typing import List, Optional
from sentence_transformers import SentenceTransformer, util


# Load model once at module level for high-performance singleton access
_model = None

def load_embedding_model() -> SentenceTransformer:
    global _model
    if _model is None:
        # Load silently
        _model = SentenceTransformer('all-MiniLM-L6-v2', device='cpu')
    return _model

def get_embedding(text: str) -> List[float]:
    """Returns a 384-dimension embedding vector for the text."""
    model = load_embedding_model()
    embedding = model.encode(text)
    return embedding.tolist()

def cosine_similarity(a: List[float], b: List[float]) -> float:
    """Computes cosine similarity between two vectors."""
    similarity = util.cos_sim(a, b)
    return float(similarity.item())

def detect_shift(current_text: str, previous_embedding: Optional[List[float]]) -> dict:
    """Detects if the current text represents a shift in topic."""
    current_embedding = get_embedding(current_text)
    
    if previous_embedding is None:
        return {"is_shift": False, "similarity": 1.0, "embedding": current_embedding}
    
    similarity = cosine_similarity(current_embedding, previous_embedding)
    is_shift = similarity < 0.35
    
    return {
        "is_shift": is_shift,
        "similarity": similarity,
        "embedding": current_embedding
    }
