from .ocr_extractor import extract_text
from .metadata_reader import get_image_info

def generate_dna_tag(image_path: str) -> str:
    """Combines OCR text and metadata into a DNA Tag string locally."""
    # 1. Get OCR Text (Local)
    ocr_text = extract_text(image_path)
    
    # 2. Get Image Metadata (Local)
    info = get_image_info(image_path)
    
    if not info:
        return "Image processing failed."
    
    # Format requested: Image [size] [format] | Colors: [colors] | Text: [ocr_text]
    dna_tag = f"Image {info.get('size', 'Unknown')} {info.get('format', 'IMG')} | Colors: {info.get('colors', 'Unknown')} | Text: {ocr_text}"
    
    return dna_tag
