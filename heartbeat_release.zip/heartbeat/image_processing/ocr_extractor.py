import pytesseract
from PIL import Image
import os

# Set tesseract path as requested
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def extract_text(image_path: str) -> str:
    """Extracts text from an image locally using Tesseract."""
    if not os.path.exists(image_path):
        return ""
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        return text.strip()
    except Exception as e:
        print(f"OCR Error: {e}")
        return ""
