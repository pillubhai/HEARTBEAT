import httpx
import json
import logging
from typing import List, Optional, Any
from heartbeat.config import get_config
from llm.key_manager import get_fallback_model, is_rate_limited

class LLMCallError(Exception):
    """Custom exception for LLM failures."""
    pass

async def call_llm(key_env_name: str, model: str, messages: List[dict], json_mode: bool = False, max_tokens: int = 1000) -> str:
    """Core function to call Groq or OpenRouter API based on key prefix."""
    config = get_config()
    api_key = getattr(config, key_env_name.lower(), config.fallback_key)
    
    if not api_key:
        raise LLMCallError("No valid API key found.")

    # --- Groq Detection ---
    is_groq = api_key.startswith("gsk_")
    base_url = config.groq_base_url if is_groq else config.openrouter_base_url
    
    # Map to Groq models if needed
    if is_groq:
        groq_model_map = {
            "openai/gpt-oss-120b:free": "llama-3.3-70b-versatile",
            "google/gemma-3-27b-it:free": "llama-3.1-8b-instant",
            "qwen/qwen3-next-80b-a3b-instruct:free": "llama-3.3-70b-versatile"
        }
        model = groq_model_map.get(model, "llama-3.1-8b-instant")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    if not is_groq:
        headers["HTTP-Referer"] = "heartbeat-agent"

    payload = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens
    }
    if json_mode and not is_groq:
        payload["response_format"] = {"type": "json_object"}

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            print(f"Calling {'Groq' if is_groq else 'OpenRouter'}: {model}")
            response = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload)
            
            # --- OpenRouter 429 Retry ---
            if not is_groq and is_rate_limited(response.status_code) and config.fallback_key:
                print("OpenRouter 429: Retrying with fallback key...")
                _, fallback_model = get_fallback_model()
                headers["Authorization"] = f"Bearer {config.fallback_key}"
                payload["model"] = fallback_model
                response = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload)
            
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except Exception as e:
            raise LLMCallError(f"LLM Error: {str(e)}")

# --- WRAPPERS ---

async def call_heart_l3(prompt: str, json_mode: bool = False) -> str:
    """Purifier: GPT-OSS-120B (K1)"""
    messages = [{"role": "user", "content": prompt}]
    return await call_llm("heart_l3_key", "openai/gpt-oss-120b:free", messages, json_mode=json_mode)

async def call_heart_l2(prompt: str) -> str:
    """Valve: Gemma 27B (K2)"""
    messages = [{"role": "user", "content": prompt}]
    return await call_llm("heart_l2_key", "google/gemma-3-27b-it:free", messages, json_mode=False)

async def call_brain(messages: List[dict]) -> str:
    """Main Chat Logic: GPT-OSS-120B (Brain Key)"""
    return await call_llm("brain_key", "openai/gpt-oss-120b:free", messages, json_mode=False)

async def call_nervous(prompt: str) -> str:
    """Dormant Trigger: Qwen 80B (Nervous Key)"""
    messages = [{"role": "user", "content": prompt}]
    return await call_llm("nervous_key", "qwen/qwen3-next-80b-a3b-instruct:free", messages, json_mode=True)
