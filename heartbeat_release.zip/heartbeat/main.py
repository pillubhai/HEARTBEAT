import uvicorn, os
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from api.routes import router
from api.websocket import websocket_endpoint
from storage.database import init_database
from heartbeat.config import get_config
from heart.metabolism import start_metabolism

app = FastAPI(title="Heartbeat Intelligence API")

# Enable CORS for browser access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register core routes
app.include_router(router)

# Register Live WebSocket Monitor
@app.websocket("/ws/connect/{user_id}")
async def websocket_route(websocket: WebSocket, user_id: str):
    await websocket_endpoint(websocket, user_id)

@app.on_event("startup")
async def startup_event():
    print("--- Initializing Heartbeat AI ---")
    
    # 0. Create data directory for isolation
    if not os.path.exists("data"):
        os.makedirs("data")
    
    # 1. Validate Config (API Keys)
    config = get_config()
    if not config.brain_key:
        print("⚠️ Warning: HEARTBEAT_BRAIN_KEY not found in .env")
    
    # 2. Init SQLite Tables (Relational Bones)
    init_database()
    print("✅ Heartbeat Database Ready.")
    
    # 3. Pre-warm the embedding model so it never loads mid-conversation
    print("🧠 Pre-loading embedding model... (one-time warmup)")
    from heart.topic_shift_detector import load_embedding_model
    load_embedding_model()
    print("✅ Embedding Model Ready. (No more mid-chat loading bars)")
    
    # 4. Start the Heart Metabolism background job (11. Automated Decay)
    start_metabolism()
    print("🧬 Heart Metabolism Thread Active.")
    
    # 5. Server Ready Notification
    print("\n[LIVE] Heartbeat running at http://0.0.0.0:8000")
    print("View Docs: http://localhost:8000/docs")


if __name__ == "__main__":
    # STABILITY LOCK: 
    # We disable reload=True because database writes and vector-store updates 
    # in the 'data/' folder were triggering recursive restart loops.
    # This ensures a 100% stable connection during your demo.
    uvicorn.run(
        "main:app", 
        host="0.0.0.0", 
        port=8000, 
        reload=False
    )
