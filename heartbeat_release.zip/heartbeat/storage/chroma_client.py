import chromadb
from chromadb.config import Settings
from heartbeat.config import get_config
from cells.cell_model import BloodCell
from sentence_transformers import SentenceTransformer
from typing import List

# Singleton model for embeddings (consistent with topic_shift_detector)
_embedding_model = None

def get_embedding_model():
    global _embedding_model
    if _embedding_model is None:
        _embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    return _embedding_model

class ChromaManager:
    """Manages the vector database for long-term memory."""
    def __init__(self):
        config = get_config()
        self.client = chromadb.PersistentClient(path=config.chroma_db_path)
        self.collection = self.client.get_or_create_collection(
            name="heartbeat_cells",
            metadata={"hnsw:space": "cosine"}
        )

    def upsert_cell(self, cell: BloodCell):
        """Adds or updates a cell in the vector store."""
        model = get_embedding_model()
        # We embed the purified summary for best semantic search
        embedding = model.encode(cell.summary).tolist()
        
        self.collection.upsert(
            ids=[cell.cell_id],
            embeddings=[embedding],
            metadatas=[{
                "user_id": cell.user_id,
                "session_id": cell.session_id,
                "topic_id": cell.topic_id or "",
                "timestamp": cell.created_at.isoformat() if hasattr(cell.created_at, "isoformat") else str(cell.created_at),
                "summary": cell.summary
            }],
            documents=[cell.summary]  # For viewing in raw format
        )

    def search_related(self, query: str, n_results: int = 5, user_id: str = None) -> List[dict]:
        """Searches for semantically related cells."""
        model = get_embedding_model()
        query_embedding = model.encode(query).tolist()
        
        where_filter = {}
        if user_id:
            where_filter["user_id"] = user_id

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
            where=where_filter if where_filter else None
        )
        # Parse return into simpler list
        formatted = []
        if results['ids'][0]:
            for i in range(len(results['ids'][0])):
                formatted.append({
                    "id": results['ids'][0][i],
                    "metadata": results['metadatas'][0][i],
                    "score": results['distances'][0][i]
                })
        return formatted

# Singleton helper
_chroma_instance = None
def get_chroma_manager():
    global _chroma_instance
    if _chroma_instance is None:
        _chroma_instance = ChromaManager()
    return _chroma_instance
