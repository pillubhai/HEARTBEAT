import sqlite3
import os
import json
from typing import List, Optional
from datetime import datetime
from heartbeat.config import get_config
from cells.cell_model import BloodCell, CellType, CellStatus, ContentType
from storage.migrations import run_migrations, create_indexes

def get_connection() -> sqlite3.Connection:
    # ULTIMATE FIX: Hard-code the absolute path to ensure no drift
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    db_path = os.path.join(base_dir, "data", "heartbeat.db")
    
    # Ensure data folder exists
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_database() -> None:
    conn = get_connection()
    try:
        create_all_tables(conn)
        create_indexes(conn)
    finally:
        conn.close()

def create_all_tables(conn: sqlite3.Connection) -> None:
    run_migrations(conn)

def save_message(msg_id: str, chat_id: str, user_id: str, role: str, content: str) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    timestamp = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT OR REPLACE INTO messages (msg_id, chat_id, user_id, role, content, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (msg_id, chat_id, user_id, role, content, timestamp))
    conn.commit()
    conn.close()

def save_cell(cell: BloodCell) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    
    # Serialize cell
    cell_dict = cell.model_dump()
    cell_dict['keywords'] = json.dumps(cell_dict.get('keywords', []))
    
    # Handle datetimes
    time_keys = ['expires_at', 'last_activated_at', 'created_at', 'entered_artery_at', 'ai_responded_at', 'purified_at', 'entered_vein_at']
    for key in time_keys:
        if cell_dict.get(key) and isinstance(cell_dict[key], datetime):
            cell_dict[key] = cell_dict[key].isoformat()
        elif cell_dict.get(key) is None:
            cell_dict[key] = None

    # Booleans
    bool_keys = ['is_ambiguous', 'is_head', 'is_chain']
    for key in bool_keys:
        if cell_dict.get(key) is not None:
            cell_dict[key] = 1 if cell_dict[key] else 0

    cursor.execute("""
        INSERT OR REPLACE INTO blood_cells (
            cell_id, user_id, chat_id, message_id, session_id,
            status, cell_type, user_raw_content, user_content,
            ai_response_summary, ai_response_full, ai_response_link_id,
            is_head, is_chain, chain_id, next_cell_id, link_id,
            importance_score, keywords, topic_id, summary, 
            is_ambiguous, clarification_question, 
            expires_at, last_activated_at, activation_count, 
            created_at, purified_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        cell_dict['cell_id'], cell_dict['user_id'], cell_dict['chat_id'], cell_dict['message_id'], cell_dict.get('session_id', 'unknown'),
        cell_dict['status'], cell_dict['cell_type'], cell_dict['user_raw_content'], cell_dict['user_content'],
        cell_dict['ai_response_summary'], cell_dict['ai_response_full'], cell_dict['ai_response_link_id'],
        cell_dict['is_head'], cell_dict['is_chain'], cell_dict['chain_id'], cell_dict['next_cell_id'], cell_dict['link_id'],
        cell_dict['importance_score'], cell_dict['keywords'], cell_dict['topic_id'], cell_dict['summary'],
        cell_dict['is_ambiguous'], cell_dict['clarification_question'], 
        cell_dict['expires_at'], cell_dict['last_activated_at'], cell_dict['activation_count'],
        cell_dict['created_at'], cell_dict['purified_at']
    ))
    conn.commit()
    conn.close()

def get_messages_by_chat(chat_id: str) -> List[dict]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp ASC", (chat_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_cell_by_id(cell_id: str) -> Optional[dict]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM blood_cells WHERE cell_id = ?", (cell_id,))
    row = cursor.fetchone()
    conn.close()
    if not row: return None
    cell = dict(row)
    if cell.get('keywords'):
        try: cell['keywords'] = json.loads(cell['keywords'])
        except: cell['keywords'] = []
    # FIX: Ensure session_id exists for Pydantic
    if 'session_id' not in cell or not cell['session_id']:
        cell['session_id'] = 'unknown'
    return cell

def get_cells_by_user(user_id: str, status: str = None) -> List[dict]:
    conn = get_connection()
    cursor = conn.cursor()
    if status:
        cursor.execute("SELECT * FROM blood_cells WHERE user_id = ? COLLATE NOCASE AND status = ? ORDER BY created_at DESC", (user_id, status))
    else:
        cursor.execute("SELECT * FROM blood_cells WHERE user_id = ? COLLATE NOCASE ORDER BY created_at DESC", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    result = [dict(row) for row in rows]
    for cell in result:
        if cell.get('keywords'):
            try: cell['keywords'] = json.loads(cell['keywords'])
            except: cell['keywords'] = []
    return result

def update_cell_status(cell_id: str, status: str) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE blood_cells SET status = ? WHERE cell_id = ?", (status, cell_id))
    conn.commit()
    conn.close()

def create_chat(chat_id, user_id, title) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    # 1. Ensure chat exists
    cursor.execute("""
        INSERT OR IGNORE INTO chats (chat_id, user_id, title, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
    """, (chat_id, user_id, title, now, now))
    # 2. Update existing chat's presence
    cursor.execute("UPDATE chats SET updated_at = ? WHERE chat_id = ?", (now, chat_id))
    conn.commit()
    conn.close()

def get_chats_by_user(user_id: str) -> List[dict]:
    # NORMALIZATION: Strip and force master mapping if applicable
    uid = user_id.strip().upper()
    if "MASTER" in uid: uid = "MASTER_USER"
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM chats WHERE user_id = ? COLLATE NOCASE ORDER BY updated_at DESC", (uid,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def save_link_vault_entry(link_id: str, cell_id: str, content_type: str, full_content: str, part_num: int, total_parts: int) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT OR REPLACE INTO link_vault (link_id, cell_id, content_type, full_content, part_number, total_parts, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (link_id, cell_id, content_type, full_content, part_num, total_parts, now))
    conn.commit()
    conn.close()

def get_messages_by_chat(chat_id: str) -> List[dict]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp ASC", (chat_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_global_user_history(user_id: str, limit: int = 30) -> List[dict]:
    # NORMALIZATION
    uid = user_id.strip().upper()
    if "MASTER" in uid: uid = "MASTER_USER"
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE user_id = ? COLLATE NOCASE ORDER BY timestamp DESC LIMIT ?", (uid, limit))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in reversed(list(rows))]
