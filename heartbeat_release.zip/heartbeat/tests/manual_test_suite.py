import asyncio
import os
import sys
from unittest.mock import patch, MagicMock

# Base tests
def test_foundation():
    print("Testing Foundation...")
    from heartbeat.config import get_config
    from cells.cell_model import CellFactory
    from storage.database import init_database
    
    config = get_config()
    assert config.max_active_cells > 0
    init_database()
    print("✅ Foundation OK")

def test_heart_sieve():
    print("Testing Heart Sieve...")
    from heart.level1_sieve import sieve
    res = sieve("hi")
    assert res["passed"] is False
    print("✅ Heart Sieve OK")

def test_circulation():
    print("Testing Circulation...")
    from circulation.artery_queue import push_cell
    from cells.cell_model import CellFactory
    
    with patch("circulation.artery_queue.get_redis_connection") as mock_redis:
        mock_r = MagicMock()
        mock_redis.return_value = mock_r
        cell = CellFactory.from_text("u1", "c1", "m1", "s1", "Test")
        assert push_cell(cell) is True
    print("✅ Circulation Mock OK")

async def test_answers():
    print("Testing Answers...")
    from answers.answer_router import route_answer
    from cells.cell_model import CellFactory
    cell = CellFactory.from_text("u1", "c1", "m1", "s1", "Test")
    cell.summary = "Test Summary"
    
    res = await route_answer("Give me a quick info", cell)
    assert "[Level 1: Quick]" in res
    print("✅ Answers OK")

async def run_all():
    print("--- HEARTBEAT MANUAL TEST SUITE ---")
    try:
        test_foundation()
        test_heart_sieve()
        test_circulation()
        await test_answers()
        print("\n🏆 ALL CORE SYSTEMS VERIFIED STABLE.")
    except Exception as e:
        print(f"\n❌ CRITICAL FAILURE: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(run_all())
