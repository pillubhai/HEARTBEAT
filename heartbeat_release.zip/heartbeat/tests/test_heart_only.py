import pytest
from unittest.mock import MagicMock, patch
from heart.level1_sieve import sieve
from heart.ambiguity_detector import detect_ambiguity
from cells.cell_model import CellFactory

def test_l1_sieve_noise():
    res = sieve("hi")
    assert res["passed"] is False

def test_ambiguity_no_llm():
    with patch("heart.ambiguity_detector.call_llm") as mocked_llm:
        mocked_llm.return_value = "{\"is_ambiguous\": false}"
        cell = CellFactory.from_text("u1", "c1", "m1", "s1", "Python is great")
        is_amb, question = detect_ambiguity(cell)
        assert not is_amb
        assert question == ""
