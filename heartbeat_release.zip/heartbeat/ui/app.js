// ── CONFIG ──────────────────────────────────────────────────────────────────
const API_BASE = window.location.origin.includes('localhost') ? '' : 'http://127.0.0.1:8000';

// ── STATE ────────────────────────────────────────────────────────────────────
// window.userId is now set in index.html to ensure persistence
if (!window.userId) window.userId = localStorage.getItem('hb_user_id') || 'MASTER_USER';
console.log("[HEARTBEAT ULTIMATE] Identity Locked:", window.userId);

let currentChatId = null;
let isLoading = false;
let pendingClarificationCellId = null;
let allChats = [];

// ── DOM REFS ─────────────────────────────────────────────────────────────────
const messagesEl   = document.getElementById('messages');
const chatListEl   = document.getElementById('chat-list');
const cellsListEl  = document.getElementById('cells-list');
const userInputEl  = document.getElementById('user-input');
const sendBtnEl    = document.getElementById('send-btn');
const newChatBtnEl = document.getElementById('new-chat-btn');
const charCountEl  = document.getElementById('char-count');
const welcomeEl    = document.getElementById('welcome');
const topbarTitle  = document.getElementById('topbar-title');
const clarifyBanner = document.getElementById('clarify-banner');
const clarifyText   = document.getElementById('clarify-text');
const clarifyDismiss = document.getElementById('clarify-dismiss');
const userAvatar   = document.getElementById('user-avatar');
const sidebarToggle = document.getElementById('sidebar-toggle');
const sidebar      = document.getElementById('sidebar');

// ── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  if (userAvatar) userAvatar.textContent = window.userId[0].toUpperCase();
  const userDisp = document.getElementById('user-display');
  if (userDisp) userDisp.textContent = 'User ' + window.userId.slice(-4);

  await loadChatsFromServer();

  const lastChat = localStorage.getItem('hb_current_chat');
  if (lastChat && allChats.find(c => c.chat_id === lastChat)) {
    loadChat(lastChat);
  } else if (allChats.length > 0) {
    loadChat(allChats[0].chat_id);
  } else {
    startNewChat();
  }

  setInterval(refreshCells, 8000);
  refreshCells();
});

// ── CHAT SYNC (FIX 17) ────────────────────────────────────────────────────────
async function loadChatsFromServer() {
    try {
        const res = await fetch(`${API_BASE}/api/chats/${window.userId}`);
        if (res.ok) {
            const data = await res.json();
            console.log("[HEARTBEAT] Loaded chats:", data.chats?.length || 0);
            allChats = data.chats || [];
            renderChatList();
        }
    } catch (e) {
        console.warn('Failed to sync chats:', e);
    }
}

// ── NEW CHAT (FIX 18) ─────────────────────────────────────────────────────────
async function startNewChat() {
  currentChatId = 'C-' + Date.now();
  localStorage.setItem('hb_current_chat', currentChatId);

  if (messagesEl) {
      Array.from(messagesEl.children).forEach(child => {
        if (child.id !== 'welcome') child.remove();
      });
  }
  
  showWelcome();
  if (topbarTitle) topbarTitle.textContent = 'New conversation';
  setActiveChatInSidebar(null);
  hideClarify();
}
window.startNewChat = startNewChat;
if (newChatBtnEl) newChatBtnEl.addEventListener('click', startNewChat);

// ── CHAT LIST ─────────────────────────────────────────────────────────────────
function renderChatList() {
  if (!chatListEl) return;
  chatListEl.innerHTML = '';
  
  if (allChats.length === 0) {
    chatListEl.innerHTML = '<div class="chat-list-empty">No conversations yet</div>';
    return;
  }

  allChats.forEach(chat => {
    const item = document.createElement('div');
    item.className = 'chat-item' + (chat.chat_id === currentChatId ? ' active' : '');
    item.dataset.chatId = chat.chat_id;
    item.innerHTML = `
      <div class="chat-item-content" onclick="loadChat('${chat.chat_id}')">
        <div class="chat-item-title">${escHtml(chat.title)}</div>
        <div class="chat-item-time">${formatTime(chat.created_at)}</div>
      </div>
      <button class="chat-item-delete" onclick="deleteChat('${chat.chat_id}', event)" title="Delete">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;
    chatListEl.appendChild(item);
  });
}

function setActiveChatInSidebar(chatId) {
  document.querySelectorAll('.chat-item').forEach(el => {
    el.classList.toggle('active', el.dataset.chatId === chatId);
  });
}

// ── DELETE CHAT (FIX 20) ──────────────────────────────────────────────────────
async function deleteChat(chatId, e) {
  if (e) e.stopPropagation();
  if (!confirm("Are you sure you want to delete this chat permanently?")) return;
  
  try {
      await fetch(`${API_BASE}/api/chats/${chatId}`, { method: 'DELETE' });
      allChats = allChats.filter(c => c.chat_id !== chatId);
      if (currentChatId === chatId) {
        startNewChat();
      } else {
        renderChatList();
      }
  } catch (e) {
      console.error("Delete failed:", e);
  }
}
window.deleteChat = deleteChat;

// ── INPUT HELPERS ─────────────────────────────────────────────────────────────
function setInput(text) {
  if (userInputEl) {
    userInputEl.value = text;
    userInputEl.focus();
    updateCharCount();
  }
}
window.setInput = setInput;

// ── LOAD CHAT ─────────────────────────────────────────────────────────────────
async function loadChat(chatId) {
  currentChatId = chatId;
  localStorage.setItem('hb_current_chat', chatId);

  const chat = allChats.find(c => c.chat_id === chatId);
  if (topbarTitle) topbarTitle.textContent = chat ? chat.title : 'Conversation';
  setActiveChatInSidebar(chatId);
  hideWelcome();
  
  if (messagesEl) {
      Array.from(messagesEl.children).forEach(child => {
        if (child.id !== 'welcome') child.remove();
      });
  }
  
  hideClarify();

  try {
    const res = await fetch(`${API_BASE}/api/history/${chatId}`);
    const data = await res.json();
    const msgs = data.messages || [];

    if (msgs.length === 0) {
      showWelcome();
    } else {
        msgs.forEach(m => appendMessage(m.role === 'user' ? 'user' : 'ai', m.content));
    }
  } catch (e) {
    showWelcome();
  }
  refreshCells();
}
window.loadChat = loadChat;

// ── SEND MESSAGE ──────────────────────────────────────────────────────────────
async function sendMessage(e) {
  if (e) e.preventDefault();
  const content = userInputEl.value.trim();
  if (!content || isLoading) return;

  // FIX 21: Handle clarification response
  if (pendingClarificationCellId) {
    await sendClarification(content);
    return;
  }

  const isNewChat = !allChats.find(c => c.chat_id === currentChatId);
  
  hideWelcome();
  hideClarify();
  appendMessage('user', content);
  userInputEl.value = '';
  updateCharCount();
  setSendLoading(true);

  const thinkingEl = appendThinking();

  try {
    const res = await fetch(`${API_BASE}/api/message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: window.userId,
        chat_id: currentChatId,
        session_id: 'browser_' + window.userId,
        content
      })
    });

    const data = await res.json();
    if (thinkingEl) thinkingEl.remove();

    // FIX 21: Clarification detection
    if (data.status === 'pending_clarification' || data.type === 'clarification') {
      pendingClarificationCellId = data.cell_id;
      const question = data.question || "I'm a bit unsure. Can you clarify that for me?";
      showClarify(question);
      appendMessage('ai', question);
    } else if (data.ai_response) {
      appendMessage('ai', data.ai_response, data.cell_id);
      
      // FIX 19: Update chat title on first message
      if (isNewChat) {
          const newTitle = content.length > 35 ? content.slice(0, 35) + '...' : content;
          await fetch(`${API_BASE}/api/chats/${currentChatId}/title`, {
              method: 'PATCH',
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({title: newTitle})
          });
          await loadChatsFromServer();
      }
    } else if (data.error || data.detail) {
      appendMessage('ai', 'Error: ' + (data.error || data.detail));
    }

    refreshCells();
  } catch (err) {
    if (thinkingEl) thinkingEl.remove();
    appendMessage('ai', '⚠️ Connection failed. Please check if backend is running.');
  }

  setSendLoading(false);
}

async function sendClarification(answer) {
  appendMessage('user', answer);
  userInputEl.value = '';
  setSendLoading(true);
  hideClarify();
  const thinkingEl = appendThinking();

  try {
    const res = await fetch(`${API_BASE}/api/clarify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        cell_id: pendingClarificationCellId,
        user_answer: answer
      })
    });
    const data = await res.json();
    if (thinkingEl) thinkingEl.remove();
    appendMessage('ai', data.message || 'Thank you, I have updated my memory.');
    pendingClarificationCellId = null;
    refreshCells();
  } catch (err) {
    if (thinkingEl) thinkingEl.remove();
    appendMessage('ai', 'Failed to resolve memory ambiguity.');
  }
  setSendLoading(false);
}

// ── UI HELPERS ────────────────────────────────────────────────────────────────
function appendMessage(role, content, cellId = null) {
  if (!messagesEl) return;
  const isAi = role === 'ai';
  const row = document.createElement('div');
  row.className = `msg-row ${isAi ? '' : 'user-row-msg'}`;
  if (cellId) row.dataset.cell = cellId;

  row.innerHTML = `
    <div class="msg-avatar ${isAi ? 'ai-av' : 'user-av'}">${isAi ? 'HB' : window.userId[0].toUpperCase()}</div>
    <div class="msg-body">
      <div class="msg-name">${isAi ? 'HEARTBEAT' : 'You'}</div>
      <div class="msg-bubble ${isAi ? 'ai-bubble' : 'user-bubble'}">${escHtml(content)}</div>
      ${isAi && cellId ? `
      <div class="depth-row">
        <button class="depth-btn" onclick="requestDepth('${cellId}', 1, this)">Summary</button>
        <button class="depth-btn" onclick="requestDepth('${cellId}', 2, this)">Detail</button>
        <button class="depth-btn" onclick="requestDepth('${cellId}', 3, this)">Original</button>
      </div>` : ''}
    </div>
  `;
  messagesEl.appendChild(row);
  scrollToBottom();
  return row;
}

async function requestDepth(cellId, level, btnEl) {
  const thinkingEl = appendThinking();
  try {
    const res = await fetch(`${API_BASE}/api/answer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: window.userId, cell_id: cellId, depth_level: level })
    });
    const data = await res.json();
    if (thinkingEl) thinkingEl.remove();
    appendMessage('ai', data.response || 'Depth data unavailable.');
  } catch (e) {
    if (thinkingEl) thinkingEl.remove();
  }
}
window.requestDepth = requestDepth;

function appendThinking() {
  const row = document.createElement('div');
  row.className = 'msg-row thinking';
  row.innerHTML = `
    <div class="msg-avatar ai-av">HB</div>
    <div class="msg-body"><div class="msg-name">HEARTBEAT</div><div class="msg-bubble ai-bubble">...</div></div>
  `;
  messagesEl.appendChild(row);
  scrollToBottom();
  return row;
}

function showWelcome() { if (welcomeEl) welcomeEl.style.display = 'flex'; }
function hideWelcome() { if (welcomeEl) welcomeEl.style.display = 'none'; }
function showClarify(q) { if (clarifyText) clarifyText.textContent = q; clarifyBanner.classList.remove('hidden'); }
function hideClarify() { clarifyBanner.classList.add('hidden'); }
function scrollToBottom() { if (messagesEl) messagesEl.scrollTop = messagesEl.scrollHeight; }
function setSendLoading(l) { isLoading = l; sendBtnEl.disabled = l; sendBtnEl.classList.toggle('loading', l); }
function updateCharCount() { charCountEl.textContent = `${userInputEl.value.length} / 4000`; }
function escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function formatTime(ts) { 
    if(!ts) return '';
    const date = new Date(ts);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// ── CELLS REFRESH ─────────────────────────────────────────────────────────────
async function refreshCells() {
    try {
        const res = await fetch(`${API_BASE}/api/cells/${window.userId}`);
        const data = await res.json();
        renderCells(data.cells || []);
    } catch (e) {}
}

function renderCells(cells) {
    if(!cellsListEl) return;
    const active = cells.filter(c => c.status === 'active');
    if(active.length === 0) {
        cellsListEl.innerHTML = '<div class="cells-empty">No active cells</div>';
        return;
    }
    cellsListEl.innerHTML = active.map(c => `
        <div class="cell-card">
            <div class="cell-card-top">
                <span class="cell-topic topic-${c.topic_id || 'general'}">${c.topic_id || 'general'}</span>
                <span class="cell-score">${c.importance_score}/10</span>
            </div>
            <div class="cell-summary">${escHtml(c.summary || c.user_content)}</div>
        </div>
    `).join('');
}

// ── EVENTS ────────────────────────────────────────────────────────────────────
if (sidebarToggle) sidebarToggle.onclick = () => sidebar.classList.toggle('collapsed');
if (userInputEl) {
    userInputEl.oninput = updateCharCount;
    userInputEl.onkeydown = e => { if(e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
}
if (sendBtnEl) sendBtnEl.onclick = sendMessage;
if (clarifyDismiss) clarifyDismiss.onclick = hideClarify;
